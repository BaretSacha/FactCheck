import React from 'react';
import './Home.css';

const Home = () => {
  return (
    <div className="home">
        <p></p>
      <header className="header">
        <div className="hero">
        <h2>Input a news you want to check!</h2>
        </div>
      </header>
    </div>
  );
};

export default Home;
